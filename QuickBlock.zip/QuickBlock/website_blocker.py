import os

WEBSITES_TO_BLOCK = [
    "PornHub.com",
    "XVideos.com",
    "XHamster.com",
    "Xnxx.com",
    "YouPorn.com",
    "RedTube.com",
    "Beeg.com",
    "TXXX.com",
    "Eporner.com",
    "Tube8.com",
    "Fuq.com",
    "PornTube.com",
    "LetMeJerk.com",
    "PornDoe.com",
    "SuperPorn.com",
    "IXXX.com",
    "Porn.com",
    "Thumbzilla.com",
    "TubeGalore.com",
    "Smutr.com",
    "IWank.com",
    "HDHole.com",
    "4Tube.com",
    "AnySex.com",
    "Tubev.com",
    "TubeSafari.com",
    "HQPorner.com",
    "ThisVid.com",
    "Porn300.com",
    "Ozeex.com",
    "4Porn.com",
    "Shameless.com",
    "MegaTube.com",
    "YOUX.com",
    "SexVid.com",
    "Fux.com",
    "AnyBunny.com",
    "MelonsTube.com",
    "ZBPorn.com",
    "PornDroids.com",
    "LargeHDTube.com",
    "BigPorn.com",
    "Pornid.com",
    "Tiava.com",
    "ClipHunter.com",
    "AssOAss.com",
    "ForHerTube.com",
    "PornerBros.com",
    "OK.com",
    "XXXBunker.com",
    "PornHeed.com",
    "LobsterTube.com",
    "DinoTube.com",
    "UFreePorn.com",
    "HotPornTubes.com",
    "PornGrey.com",
    "PalmTube.com",
    "ViviPorn.com",
    "PornFaze.com",
    "Fapster.com",
    "Pornito.com",
    "Slutroulette.com",
    "JerkMate.com",
    "CamSoda.com",
    "iChatOnline.com",
    "LivePornGirls.com",
    "MilfsLive.com",
    "NaughtyAmerica.com",
    "BangBrosNetwork.com",
    "Bang.com",
    "TeamSkeet.com",
    "DogfartNetwork.com",
    "MofosNetwork.com",
    "21Sextury.com",
    "BabesNetwork.com",
    "DigitalPlayground.com",
    "HentaiHaven.com",
    "XvideosHentai.com",
    "Fakku.com",
    "NHentai.com",
    "SpankBangHentai.com",
    "MyHentaiComics.com",
    "MyHentaiGallery.com",
    "Porcore.com",
    "CartoonPorno.com",
    "Nutaku.com",
    "PornGamesHub.com",
    "Gamcore.com",
    "GamesOfDesire.com",
    "PornGames.com",
    "SexEmulator.com"
]

HOSTS_PATH = r"C:\Windows\System32\drivers\etc\hosts"
REDIRECT_IP = "127.0.0.1"

def is_website_blocked(website):
    with open(HOSTS_PATH, 'r') as hosts_file:
        contents = hosts_file.read()
        if f"{REDIRECT_IP} {website}" in contents or f"{REDIRECT_IP} www.{website}" in contents:
            return True
    return False

def block_website(website):
    with open(HOSTS_PATH, 'a') as hosts_file:
        hosts_file.write(f"{REDIRECT_IP} {website}\n")
        hosts_file.write(f"{REDIRECT_IP} www.{website}\n")

def block_websites():
    for website in WEBSITES_TO_BLOCK:
        clean_website = website.replace('http://', '').replace('https://', '').replace('www.', '')
        if is_website_blocked(clean_website):
            print(f"{clean_website} is already blocked.")
        else:
            block_website(clean_website)
            print(f"{clean_website} successfully blocked.")

if __name__ == "__main__":
    block_websites()